document.addEventListener('DOMContentLoaded', function() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const previewContainer = document.getElementById('previewContainer');
    const previewImage = document.getElementById('previewImage');
    const resultsContainer = document.getElementById('resultsContainer');
    const predictionsList = document.getElementById('predictionsList');
    const cvResultsContainer = document.getElementById('cvResultsContainer');
    const spinner = document.getElementById('spinner');

    // Drag and drop handlers
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '#2980b9';
    });

    dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '#3498db';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '#3498db';
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            handleImage(file);
        }
    });

    // File input handler
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            handleImage(file);
        }
    });

    function handleImage(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            previewImage.src = e.target.result;
            previewContainer.style.display = 'block';
            predictImage(file);
        };
        reader.readAsDataURL(file);
    }

    function createPredictionElement(prediction, index) {
        const div = document.createElement('div');
        div.className = 'prediction-item';
        div.innerHTML = `
            <div class="prediction-rank">${index + 1}</div>
            <div class="prediction-details">
                <div class="prediction-class">${prediction.class}</div>
                <div class="prediction-confidence">Confidence: ${prediction.confidence}</div>
            </div>
        `;
        return div;
    }

    function displayProcessedImages(processedImages) {
        document.getElementById('originalImage').src = `data:image/png;base64,${processedImages.original}`;
        document.getElementById('edgeImage').src = `data:image/png;base64,${processedImages.edges}`;
        document.getElementById('contourImage').src = `data:image/png;base64,${processedImages.contours}`;
        document.getElementById('colorImage').src = `data:image/png;base64,${processedImages.color_analysis}`;
        cvResultsContainer.style.display = 'block';
    }

    async function predictImage(file) {
        spinner.style.display = 'block';
        predictionsList.innerHTML = '';
        resultsContainer.style.display = 'none';
        cvResultsContainer.style.display = 'none';

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/predict', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Prediction failed');
            }

            const data = await response.json();
            
            // Display predictions
            data.predictions.forEach((prediction, index) => {
                predictionsList.appendChild(createPredictionElement(prediction, index));
            });
            resultsContainer.style.display = 'block';

            // Display processed images
            if (data.processed_images) {
                displayProcessedImages(data.processed_images);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error processing image. Please try again.');
        } finally {
            spinner.style.display = 'none';
        }
    }
}); 